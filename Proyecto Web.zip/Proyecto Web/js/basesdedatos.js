const firebaseConfig = {
  apiKey: "AIzaSyA6X4ZuEcnobsr-UkWmc-VV3gXfMkRrmKA",
  authDomain: "base-14f94.firebaseapp.com",
  projectId: "base-14f94",
  storageBucket: "base-14f94.appspot.com",
  messagingSenderId: "1051762909258",
  appId: "1:1051762909258:web:6ed966a3c73b2d6951c6b3"
};
firebase.initializeApp(firebaseConfig);

  let db = firebase.firestore();

  db.collection("productos").get().then((querySnapshot) => {
  querySnapshot.forEach((doc) => {
      console.log(doc.data().Nombre);
      console.log(doc.data().Precio);
      console.log(doc.data().Cantidad);
    });
  });


function guardar(){
    db.collection("productos").add({
    nombre: document.getElementById('idNombre').value,
    usuario: document.getElementById('idEmail').value,
    contraseña: document.getElementById('idPass').value,
    })
    .then((docRef) => {
      console.log("Document written with ID: ", docRef.id);
    })
    .catch((error) => {
      console.error("Error adding document: ", error);
    })
   }
